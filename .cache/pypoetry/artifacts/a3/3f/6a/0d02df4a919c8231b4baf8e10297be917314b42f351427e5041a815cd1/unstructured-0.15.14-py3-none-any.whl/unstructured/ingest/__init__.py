from __future__ import annotations

import warnings

warnings.warn(
    "unstructured.ingest will be removed in a future version. "
    "Functionality moved to the unstructured-ingest project.",
    DeprecationWarning,
    stacklevel=2,
)
