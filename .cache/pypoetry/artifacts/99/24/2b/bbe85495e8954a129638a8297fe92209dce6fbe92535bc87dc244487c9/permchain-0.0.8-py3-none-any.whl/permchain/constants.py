CONFIG_KEY_SEND = "__pregel_send"
CONFIG_KEY_READ = "__pregel_read"
CHECKPOINT_KEY_VERSION = "__pregel_version"
CHECKPOINT_KEY_TS = "__pregel_ts"
