# -*- coding: utf-8 -*-


class ValidationError(Exception):
    pass
