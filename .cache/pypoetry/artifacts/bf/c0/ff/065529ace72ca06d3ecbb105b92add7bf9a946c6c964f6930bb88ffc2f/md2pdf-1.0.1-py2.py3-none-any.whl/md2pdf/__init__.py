# -*- coding: utf-8 -*-
__title__ = "md2pdf"
__author__ = "Julien Maupetit"
__license__ = "MIT"
__copyright__ = "Copyright 2013-2023 Julien Maupetit"

from .core import md2pdf  # noqa
from .version import __version__  # noqa
