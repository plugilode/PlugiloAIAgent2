# -*- coding: utf-8 -*-

# Test files paths
INPUT_CSS = 'tests/resources/input.css'
INPUT_MD = 'tests/resources/input.md'
OUTPUT_PDF = 'tests/resources/output.pdf'
